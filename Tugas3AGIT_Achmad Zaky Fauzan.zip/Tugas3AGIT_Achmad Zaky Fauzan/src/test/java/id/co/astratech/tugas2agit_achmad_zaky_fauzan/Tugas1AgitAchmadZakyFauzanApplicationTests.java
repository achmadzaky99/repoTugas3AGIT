package id.co.astratech.tugas2agit_achmad_zaky_fauzan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Tugas1AgitAchmadZakyFauzanApplicationTests {

	@Test
	void contextLoads() {
	}

}

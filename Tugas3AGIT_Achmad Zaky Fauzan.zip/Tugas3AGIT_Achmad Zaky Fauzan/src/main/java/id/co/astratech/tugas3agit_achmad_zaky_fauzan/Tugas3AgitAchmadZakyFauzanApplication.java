package id.co.astratech.tugas3agit_achmad_zaky_fauzan;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Tugas3AgitAchmadZakyFauzanApplication {

	public static void main(String[] args) {
		SpringApplication.run(Tugas3AgitAchmadZakyFauzanApplication.class, args);
	}

}
